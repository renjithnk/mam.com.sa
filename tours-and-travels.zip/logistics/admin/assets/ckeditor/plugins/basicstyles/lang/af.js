﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'af', {
	bold: 'Vet',
	italic: 'Skuins',
	strike: 'Deurgestreep',
	subscript: 'Onderskrif',
	superscript: 'Bo-skrif',
	underline: 'Onderstreep'
} );
