﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'basicstyles', 'fo', {
	bold: 'Feit skrift',
	italic: 'Skráskrift',
	strike: 'Yvirstrikað',
	subscript: 'Lækkað skrift',
	superscript: 'Hækkað skrift',
	underline: 'Undirstrikað'
} );
