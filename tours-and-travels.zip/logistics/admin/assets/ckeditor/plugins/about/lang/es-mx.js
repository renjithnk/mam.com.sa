﻿/*
Copyright (c) 2003-2019, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'about', 'es-mx', {
	copy: 'Derechos reservados &copy; $1. Todos los derechos reservados',
	dlgTitle: 'Acerca de CKEditor 4',
	moreInfo: 'Para información sobre la licencia por favor visita nuestro sitio web:'
} );
