<div class="sidebar-form">
        <h2 class="sidebar-form__heading">Or Get A Callback</h2>
      <form class="form sidebar-form__container">

<div class="form__row sidebar-form__row1">
<div class="form__col sidebar-form__row1-col1">
<div class="form__field-container">
<input type="text" class="form__input-text" placeholder="Name">
<div class="form__validation">Validation</div>
</div>
</div>
</div>

<div class="form__row sidebar-form__row2">
<div class="form__col sidebar-form__row2-col1">
<div class="form__field-container">
<input type="text" class="form__input-text" placeholder="E-mail">
<div class="form__validation">Validation</div>
</div>
</div>


</div>

<div class="form__row sidebar-form__row3">
<div class="form__col sidebar-form__row3-col1">
<div class="form__field-container">
<input type="text" class="form__input-text" placeholder="Mobile No">
<div class="form__validation">Validation</div>
</div>
</div>
</div>


<div class="form__row sidebar-form__row4">
<div class="form__col sidebar-form__row4-col">
<textarea class="form__input-textarea" name="" id="" cols="30" rows="5" placeholder="Message"></textarea>
</div>
</div>

<button class="form__submit btn1" type="submit">Submit</button>
</form>
      </div>